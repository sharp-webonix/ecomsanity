import React from "react";
import HeroSection from "./components/HeroSection";
import Services from "./components/Services";

const Home = () => {
  const data = {
    name: "Sharp System",
  };

  return (
    <>
      <HeroSection myData={data} />
      <Services />
    </>
  );
};

export default Home;