import React, { useEffect, useState } from "react";
import styled from "styled-components";
import { urlFor, client } from "./client";
import { motion } from 'framer-motion';
import { NavLink } from "react-router-dom";
import FilterSection from "./components/FilterSection";
import Sort from "./components/Sort";
import ProductList from "./components/ProductList";

const Products = () => {
  const [products, setProduct] = useState([]);

  useEffect(() => {
    const query = `*[_type=="product" ]`;
    client.fetch(query).then((data) => {
      setProduct(data);
    })
  }, [])
  console.log(products)
  return <Wrapper>
    <div className="product">
      {products.map((product, index) => (
        <motion.div
          whileInView={{ opacity: 1 }}
          whileHover={{ scale: 1.1 }}
          transition={{ duration: 0.5, type: 'tween' }}
          key={index}
        >
          <img src={urlFor(product.imgUrl && product.imgUrl[0])} alt={product.title} />
          <h4 style={{ marginTop: 20 }}>{product.title}</h4>
          {/* <h3  style={{ marginTop: 20 }}>{product.description}</h3> */}
          <h4 style={{ marginTop: 20 }}>{product.detail}</h4>
          <h4 style={{ marginTop: 20 }}>{product.price}</h4>
            <NavLink to="/cart">
              <button className="btn-cart">Add to Cart</button>
            </NavLink>
            <NavLink to={`/singleproduct/:${product.slug.current}`}>
              <button className="btn-cart">View More</button>
            </NavLink>
        </motion.div>
      ))}
    </div>
    <div className="container grid grid-filter-column">
        <div>
          <FilterSection />
        </div>

        <section className="product-view--sort">
          <div className="sort-filter">
            <Sort />
          </div>
          <div className="main-product">
            <ProductList />
          </div>
        </section>
      </div>

  </Wrapper>;
};

const Wrapper = styled.section`
.product{
  display: flex;
    flex-direction: row;
    flex-wrap: wrap;
    align-items: baseline;
    justify-content: space-around;
    align-content: center;
    max-width: 1400px;
    margin: auto;
}
.product div{
  width: 300px;
  border:1px solid ;
  text-align:center;
  margin: 50px;
  padding: 30px;
}
.product div img {
  width: 200px;
  height: 200px;
}

.product div button{
  margin: auto;
  margin-top: 10px;
  padding: 10px;
}

  .grid-filter-column {
    grid-template-columns: 0.2fr 1fr;
  }
 

  @media (max-width: ${({ theme }) => theme.media.mobile}) {
    .grid-filter-column {
      grid-template-columns: 1fr;
    }
  }
  button{
    ${'' /* align-items:center; */}
    cursor:pointer;
  
  }
  .btn-cart{
    
    display:flex;
    align-items:center;
    position:relative;
    
  }
  .btn{
    align-items:center;
  }
`;

export default Products;