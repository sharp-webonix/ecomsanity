import React ,{useState} from 'react'
import styled from 'styled-components';
import {NavLink} from 'react-router-dom';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const Registration = () => {
  const [email, setemail] = useState("")
  const [password, setpassword] = useState("")
  const [name, setname] = useState("")
  const [phone, setphone] = useState("")
  const onchange = (e) => {
    if (e.target.name === 'email') {
      setemail(e.target.value)
    }
    else if (e.target.name === 'password') {
      setpassword(e.target.value)
    }
    else if (e.target.name === 'name') {
      setname(e.target.value)
    }
    else if (e.target.name === 'phone') {
      setphone(e.target.value)
    }
  }
  const handleSubmit = async (e) => {
    e.preventDefault()
    const data = { name, email, password, phone }
    const res = await fetch(`http://localhost:5000/api/auth/createuser`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(data),
    })
    let response = await res.json();
    setemail("")
    setname("")
    setpassword("")
    setphone("")

    if (response.success) {
      toast.success('Your account have been created', {
        position: "bottom-left",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "light",
      });
    }
  }
  return (
    <>
    <div>
      <ToastContainer
        position="top-left"
        autoClose={5000}
        hideProgressBar={false}
        newestOnTop={false}
        closeOnClick
        rtl={false}
        pauseOnFocusLoss
        draggable
        pauseOnHover
        theme="light"
      />
      </div>
    <Wrapper>
    <section class="container">
    <header>Registration Form</header>
    <form  onSubmit={handleSubmit} class="form">
      <div class="input-box">
        <label>Full Name</label>
        <input onChange={onchange} name='name' value={name} type="text" placeholder="Enter full name" required />
      </div>

      <div class="input-box">
        <label>Email Address</label>
        <input  onChange={onchange} name='email' value={email} type="email" placeholder="Enter email address" required />
      </div>

      <div class="input-box">
        <label>Password</label>
        <input  onChange={onchange} name='password' value={password} type="password" placeholder="Enter Password" required />
      </div> 

      <div class="column">
        <div class="input-box">
          <label>Phone Number</label>
          <input onChange={onchange} name='phone' value={phone} type="tel" placeholder="Enter phone number" required />
        </div>
      </div>
      {/* <div class="input-box address">
        <label>Address</label>
        <input onChange={onchange} type="text" placeholder="Enter street address" required /> */}
        {/* <input onChange = {onchange} type="text" placeholder="Enter street address line 2" required /> */}
        {/* <div class="column">
          <input onChange={onchange} type="text" placeholder="Enter your city" required />
        </div> */}
        {/* <div class="column"> */}
          {/* <input onChange={onchange} type="text" placeholder="Enter your region" required /> */}
          {/* <input onChange={onchange} type="number" placeholder="Enter postal code" required />
        </div>
      </div> */}
      <button>Submit</button>
      <div class="signup_link">
          Already have an account? 
              <NavLink to="/login">
              SignIn
            </NavLink>
        </div>
    </form>
  </section>
  </Wrapper>
  </>
  )
};
const Wrapper = styled.section`
/* Import Google font - Poppins */
@import url("https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;700&display=swap");
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-family: "Poppins", sans-serif;
  font-size:13px;
}
body {
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 20px;
  background: rgb(130, 106, 251);
}
.container {
  position: relative;
  max-width: 500px;
  width: 100%;
  background: #fff;
  padding: 25px;
  border-radius: 8px;
  box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
  margin-left: 450px;
  margin-top: 20px;

}
.container header {
  font-size: 1.5rem;
  color: #333;
  font-weight: 500;
  text-align: center;
}
.container .form {
  margin-top: 30px;
}
.form .input-box {
  width: 100%;
  margin-top: 20px;
}
.input-box label {
  color: #333;
}
.form :where(.input-box input, .select-box) {
  position: relative;
  height: 50px;
  width: 100%;
  outline: none;
  font-size: 1rem;
  color: #707070;
  margin-top: 8px;
  border: 1px solid #ddd;
  border-radius: 6px;
  padding: 0 15px;
}
.input-box input:focus {
  box-shadow: 0 1px 0 rgba(0, 0, 0, 0.1);
}
.form .column {
  display: flex;
  column-gap: 15px;
}
.form .gender-box {
  margin-top: 20px;
}
.gender-box h3 {
  color: #333;
  font-size: 1rem;
  font-weight: 400;
  margin-bottom: 8px;
}
.form :where(.gender-option, .gender) {
  display: flex;
  align-items: center;
  column-gap: 50px;
  flex-wrap: wrap;
}
.form .gender {
  column-gap: 5px;
}
.gender input {
  accent-color: rgb(130, 106, 251);
}
.form :where(.gender input, .gender label) {
  cursor: pointer;
}
.gender label {
  color: #707070;
}
.address :where(input, .select-box) {
  margin-top: 15px;
}
.select-box select {
  height: 100%;
  width: 100%;
  outline: none;
  border: none;
  color: #707070;
  font-size: 1rem;
}
.form button {
  height: 55px;
  width: 100%;
  color: #fff;
  font-size: 1rem;
  font-weight: 400;
  margin-top: 30px;
  border: none;
  cursor: pointer;
  transition: all 0.2s ease;
  background: rgb(130, 106, 251);
}
.form button:hover {
  background: rgb(88, 56, 250);
}
/*Responsive*/
@media screen and (max-width: 500px) {
  .form .column {
    flex-wrap: wrap;
  }
  .form :where(.gender-option, .gender) {
    row-gap: 15px;
  }
}

.signup_link{
  padding: 10px;
    font-size: 15px;
    font-weight: bold;
    font-style: italic;
    margin: 15px 100px 0px -10px;
}

${'' /* @media screen and (max-width: 769px) {
.container{
margin:auto;
}
} */}
@media screen and (max-width: 1200px) {
.container{
margin:auto;
}
}

`;
export default Registration
