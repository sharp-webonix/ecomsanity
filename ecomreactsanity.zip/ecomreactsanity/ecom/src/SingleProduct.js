import { useEffect, useState } from "react";
import styled from "styled-components";
import { useParams } from "react-router-dom";
import { urlFor ,client } from "./client";
import { motion } from 'framer-motion';
import { NavLink } from "react-router-dom";
import PageNavigation from "./components/Pagenavigation";





const SingleProduct = () => {
  const [products, setProduct] = useState([]);
  const { slug } = useParams()
  useEffect(() => {
    const query = `*[slug.current==${products.slug.current} ]`;
    client.fetch(query).then((data) => {
      setProduct(data);
    })
  }, )
  console.log(products)
  return <Wrapper>
  <PageNavigation  />
    <div className="product">
      {products.map((product, index) => (
        <motion.div
          whileInView={{ opacity: 1 }}
          whileHover={{ scale: 1.1 }}
          transition={{ duration: 0.5, type: 'tween' }}
          key={index}
        >
          <img src={urlFor(product.imgUrl && product.imgUrl[0])} alt={product.title} />
          <h4 style={{ marginTop: 20 }}>{product.title}</h4>
          {/* <h3  style={{ marginTop: 20 }}>{product.description}</h3> */}
          <h4 style={{ marginTop: 20 }}>{product.detail.current}</h4>
          <h4 style={{ marginTop: 20 }}>{product.price.current}</h4>
            <NavLink to="/cart">
              <button className="btn-cart">Add to Cart</button>
            </NavLink>
            {/* <NavLink to={`/singleproduct/:${product.slug.current}`}>
              <button className="btn-cart">View More</button>
            </NavLink> */}
        </motion.div>
      ))}
    </div>

  </Wrapper>;
  
};

const Wrapper = styled.section`
  .container {
    padding: 9rem 0;
  }
  .product-data {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: center;
    gap: 2rem;

    .product-data-warranty {
      width: 100%;
      display: flex;
      justify-content: space-between;
      align-items: center;
      border-bottom: 1px solid #ccc;
      margin-bottom: 1rem;

      .product-warranty-data {
        text-align: center;

        .warranty-icon {
          background-color: rgba(220, 220, 220, 0.5);
          border-radius: 50%;
          width: 4rem;
          height: 4rem;
          padding: 0.6rem;
        }
        p {
          font-size: 1.4rem;
          padding-top: 0.4rem;
        }
      }
    }

    .product-data-price {
      font-weight: bold;
    }
    .product-data-real-price {
      color: ${({ theme }) => theme.colors.btn};
    }
    .product-data-info {
      display: flex;
      flex-direction: column;
      gap: 1rem;
      font-size: 1.8rem;

      span {
        font-weight: bold;
      }
    }

    hr {
      max-width: 100%;
      width: 90%;
      /* height: 0.2rem; */
      border: 0.1rem solid #000;
      color: red;
    }
  }

  .product-images {
    display: flex;
    justify-content: center;
    align-items: center;
  }

  @media (max-width: ${({ theme }) => theme.media.mobile}) {
    padding: 0 2.4rem;
  }
`;

export default SingleProduct;