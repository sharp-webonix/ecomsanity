import sanityClient from '@sanity/client'
import imageUrlBuilder from '@sanity/image-url';
// 
export const client = sanityClient({
  projectId:  "s3la63bk",
  dataset: 'production',
  apiVersion: '2022-11-01',
  useCdn: true,
  token: "skUYQ5ljL0Bh0xZTGI8F6579l41ChjTwlQMG0UNr4tlptO31XhAibe0pBLaTbEnw2FCiVJfhyzImdBPO4ZxROXGf63cJNBLeZ2U72dB3zbbda69Ad4gbEGmZEoXTsIfBf4cKXKh7XcK794n8n9WQ0KTARUzzIARMNxW6udesKtKK6lJusBIg",
  ignoreBrowserTokenWarning: true
});

const builder = imageUrlBuilder(client);

export const urlFor = (source) => builder.image(source);