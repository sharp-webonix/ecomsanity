import product from './products';
import about from './about';
export const schemaTypes = [product , about]
