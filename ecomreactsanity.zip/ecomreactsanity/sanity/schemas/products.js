export default {
    name: 'product',
    title: 'Product',
    type: 'document',
    fields: [
        {
            name:'title',
            title:'Title',
            type:'string'
        },
        {
            name:'description',
            title:'Description',
            type:'string'
        },
        {
            name:'detail',
            title:'Detail',
            type:'string'
        },
        {
            name:'price',
            title:'Price',
            type:'number'
        },
        { 
            name: 'slug',
            title: 'Slug',
            type: 'slug',
            options: {
              source: 'name',
              maxLength: 90,
            },
        },
        {
            name:'imgUrl',
            title:'ImgUrl',
            type: 'array',
            of: [{type: 'image'}],
            options: {
              hotspot: true,
            },
        },
    ]
}